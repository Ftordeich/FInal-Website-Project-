const SQL = require("sql-template-strings");
const dbPromise = require("./database.js");

async function createComment(comment) {
    const db = await dbPromise;

    const result = await db.run(SQL`
    insert into comment(user_id, username, user_comment, comment_likes, date_created, article_id) values 
        (${comment.user_id}, ${comment.username}, ${comment.content}, ${comment.commentLikes}, date('now'), ${comment.article_id});
    `);
    comment.id = result.lastID;
}

async function retrieveCommnetById(id) {
    const db = await dbPromise;

    const result = await db.get(SQL`
        select * from comment 
        where id = ${id}`);

    return result;
}

async function retrieveAllComments() {
    const db = await dbPromise;

    const result = await db.all(SQL`select * from comment`);

    return result;
}

async function updateComment(comment) {
    const db = await dbPromise;

    return await db.run(SQL`
        update comment
        set user_comment = ${comment.user_comment}
        where  id = ${comment.id}`);
}

async function deleteComment(id) {
    const db = await dbPromise;

    return await db.run(SQL`
        delete from comment
        where id = ${id}`);
}

async function retrieveCommentsOfArticle(articleId){
    const db = await dbPromise;

    return await db.all(SQL`
        select * from comment
        where article_id = ${articleId}`);
}

async function likeComment(comment){
    const db = await dbPromise;

    return await db.all(SQL`
        update comment 
        set comment_likes = ${comment.comment_likes}
        where id = ${comment.id}`);
}


// Export functions.
module.exports = {
    createComment,
    retrieveCommnetById,
    retrieveAllComments,
    updateComment,
    deleteComment,
    retrieveCommentsOfArticle,
    likeComment
};
