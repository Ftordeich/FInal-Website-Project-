const SQL = require("sql-template-strings");
const dbPromise = require("./database.js");

async function createMessage(message) {
    const db = await dbPromise;

    const result = await db.run(SQL`
        insert into message (sender_id, receiver_id, body, date_created)
        values(${message.senderId}, ${message.receiverId},  ${message.body}, datetime('now'))`);
    message.id = result.lastID;
}

/**Retrieve all messages sent and received by two users.
 * @param {senderId, receiverId} the id of the sender and receiver.
 * @return {messsages} an array of message objects, list from old to new.
 * A message object contain date_created, title, message body, the username of sender*/

async function retrieveMessages(senderId, receiverId){
    const db = await dbPromise;

    const messages = await db.all(SQL`
    select m.sender_id, m.receiver_id, m.body, m.date_created, s.username
    from message m, user s
    where (((sender_id = ${senderId}
    and receiver_id = ${receiverId})
    or(
    sender_id = ${receiverId}
    and receiver_id = ${senderId}))
     and m.sender_id = s.id)
    order by m.date_created`)
    ;

    return messages;
}


async function deleteMessage(id) {
    const db = await dbPromise;

    await db.run(SQL`
        delete from messages
        where id = ${id}`);
}

// Export functions.
module.exports = {
    createMessage,
    retrieveMessages,
    deleteMessage
};
