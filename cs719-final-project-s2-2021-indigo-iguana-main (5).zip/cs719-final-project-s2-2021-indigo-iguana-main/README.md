Final project &ndash; Pokemon Collect: Blogging system &ndash; 
==========
## Team indigo-iguana

This Team Project has been completed by: 
Cameron Flick (Team Leader)
Youwei Huang
Felix Mcmullin
Frank Peng

## A brief introduction to your webapp

Pokemon Collect is a blogging system webapp, where users can 1) post information and/or attach images 2)comment of other users posts 3) send and recieve private chat with other users. 

## Project structure

This section details the structure of the given starter project, and provides information on the existing files.

### Root folder

Application Folders:
- `dabatabase`
- `middleware`
- `modules`
- `public`
- `routes`
- `sql`

Concept / Trail Folders:
- `assets`
- `static-ui`

### `public` folder

The files in this folder is served to the webapp.
This folder contains all the css, fonts, static frontend javascript and images used for the site. User avatars are uploaded in to the `images/avatar/` folder

### `views` folder

contains all the handlebars templates used within the site. 

### `static-ui` folder

Contains the static HTML and CSS used to design the web app they are not used within the webapp.

## Completed compulsory features

All compulsory features (feature 1 ~ feature 11) completed, including The research features.

## Completed Extra features

All Extra features (extra feature 1 ~ extra feature 5) completed
1. Filter Drop Down button with sort all post by popularity (number of comments) and sort all post by post date
2. User can upload their own Avatar and use their own avatar
3. “Like” Button/Emoji on the bottom right corner of each post card div, users can use this button to React to posts. (we have altered this feature, so now the like button is used for liking a comment.) 
4. It also have a number count (i.e. number of likes)
5. Private Message other users by clicking on their avatar

## Database Naming
project-databse.db

## Initialising and Running the WebApp

1. Obtain the code via `git clone` command of the repository: https://github.com/UOA-COMPSCI719/module-07-lab-nodejs-express-frankauckland.git
2. Using DB Browser for SQLite create the `project-databse.db` in the root directory 
3. Populate the database by executing `populate-database.sql` in DB Browser for SQLite and write changes to the `project-database.db` file
4. Install Node.js via `npm install` in your IDE terminal
5. Run`npm start`using your IDE terminal 
6. Use your browser to navigate to http://localhost:3000/

## Instructions for using the WebApp

### To Login:

1. Once you have an account, click on the login button on the right (For Testing purposes use `Username: Ash`
`Password: 1` )
2. login with your login username and password

### To Create an account:

1. Go to http://localhost:3000/
2. Register a new account by first clicking on `login`
3. `Sign up`
4. Create your login details and click Next button (all passwords are encrypted using bcrypt)
5. Once an account has been created you will be automatically logged in

### To Delete an account:

1. Once logged in, hover on your avatar and the full main menu with your username will appear
2. Click on your username
3. Click on `Delete Account` on the botton of the page
[ IMPORTANT NOTE: Deleting an account will delete the users account, including all Posts and Comments that user has made ]

### To Logout:

1. Once logged in, a `logout` textbutton will appear below your avatar icon

### To Change your account details:

1. Once logged in, hover on your avatar and the full main menu with your username will appear
2. Click on your username
3. Edit and confirm your change

### To Change/upload your avatar:

first time choosing your avatar:
1. Once logged in, click on the avatar icon with the empty `change avatar` avatar 
2. Select an avatar from the page and click `Done`
Changing your avatar:
1. Once logged in, click on the avatar icon
2. Select another avatar from the page and click `Done`
Upload your Custom avatar:
1. Once logged in, click on the avatar icon
2. Select `Upload your own`, to choose youe avatar picture from your local storage
3. The image will be uploaded in the backgroun, Click `Done` to complete

### To Write a Post:

1. Once logged in, click on `New post` button in the main navigation menu
2. Write your title and post with the WYSIWYG Editor, you can also include images in the post
3. Click post to post

### To Edit or Delete a Post:

1. Once logged in, click on `My post` button to show all the post you have authored (if no post was created, nothing will show here
2. Edit or Delete with the `Edit` or `Delete` button

### To Comment on a Post:

1. Once logged in, click within the comment textarea below each post.
2. Write your comment
3. Click `Post Comment` to post this comment

### To Like a comment:

1. Once logged in, click within the comment textarea below each post.

### To Filter posts:

posts can be filtered by `Newest`, `Oldest` ,`Least Comments` and `Most Comments`
you can filter all posts with any of these filters by clicking on their relative buttons on the home page


### To Chat:

1. Once logged in, click on any post author's avatar or hover left and select any avatar
2. Redirects to the chat page, with the selected avatar being the receiver, all send and received messages will be displayed here
3. Send a chat message by typing in the chat textarea and clicking send


## Test Username / Password

Use the below login details to test the webapp
Username: Ash
Password: 1
