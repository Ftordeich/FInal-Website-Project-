//This file provides routers for messgaes

const express = require("express");
const router = express.Router();
const { verifyAuthenticated } = require("../middleware/auth-middleware.js");

const messageDao = require("../modules/message-dao.js");


router.post("/viewMessage", verifyAuthenticated, async function (req, res) {
    const senderId = res.locals.user.id;
    const message = {
        senderId : senderId.toString(),
        receiverId: req.query.id,
        body: req.body.body
    }
    await messageDao.createMessage(message);
    res.redirect(`/viewMessage?id=${message.receiverId}`);
});

router.get("/viewMessage", verifyAuthenticated, async function (req,res){
    const currentUser = res.locals.user.id;
    const otherUser = req.query.id;
    const allMessages = await messageDao.retrieveMessages(currentUser, otherUser);
    res.locals.messages = allMessages;
    res.render("message", {layout:"editor", title: "Chat", css: ['editor.css']});
});

module.exports = router;