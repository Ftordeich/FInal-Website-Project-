//This file provides routers for the articles seen on the main page 

const express = require("express");
const router = express.Router();
const { verifyAuthenticated } = require("../middleware/auth-middleware.js");

const articleDao = require("../modules/article-dao.js");


/**If user have login, render the newArticle view, else redirect to the login*/
router.get("/newArticle",verifyAuthenticated,async function (req,res){
   res.render("post-new-post", {layout:"editor", title: "New Post", css: ['editor.css'] });
});


/** A route for publish a new articles.
 * First check if user already login. If so create an article object with attributes from post request.*/
router.post("/newArticle", async function (req, res) {
    const user = res.locals.user;
    const article = {
        title : req.body.title,
        author: user.username,
        created_by_id: user.id,
        tinyMCE: req.body.mytextarea,
        user_avatar: user.avatar
    };

    await articleDao.createArticle(article);
    res.redirect("/");
});

/** First check if user have login, then it get the user id and check if the user is the author of the article.
 * If both condition are ture, the editArticle view is rendered  (user can edit the article).
 */
router.get("/editArticle", verifyAuthenticated,async function (req,res){
   const articleId = req.query.article_id;
   const article  = await articleDao.retrieveArticleById(articleId);
   const userId = article.created_by_id;

   if(userId == res.locals.user.id){
       res.locals.article_title = article.title;
       res.locals.article_content = article.tiny_mce;
       res.locals.date_created = article.date_created;
       res.render("post-new-post", {layout:"editor", title: "Edit Post", css: ['editor.css'] });
   }

   else{
       res.setToastMessage("You do not have permission to edit the article");
       res.redirect("/");
   }
});

/** An user can only edit the article title and content.*/
router.post("/editArticle",  async function (req,res){
    const articleId = req.query.article_id;
    const article = await articleDao.retrieveArticleById(articleId);
    article.title = req.body.title;
    article.tinyMCE = req.body.mytextarea;
    await articleDao.updateArticle(article);
    res.redirect("/");
})

/** An user can delete his articles*/
router.post("/deleteArticle", verifyAuthenticated, async function (req,res){
    const articleId = req.body.article_id;
    const article  =await articleDao.retrieveArticleById(articleId);
    const userId = article.created_by_id;
    if (userId == res.locals.user.id){
        await articleDao.deleteArticle(articleId);
        res.setToastMessage("The article is safely deleted");
    }
    else {
        res.setToastMessage("You do not have permission to delete the article");
    }
    res.redirect("/");
});

module.exports = router;