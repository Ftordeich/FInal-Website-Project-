const express = require("express");
const router = express.Router();

const { verifyAuthenticated } = require("../middleware/auth-middleware.js");
const usersDao = require("../modules/user-dao.js");
const articleDao = require("../modules/article-dao.js");
const commentDao = require("../modules/comment-dao.js");

let listOfArticles;
let userAvatarIcons;
// Whenever we navigate to /, verify that we're authenticated. If we are, (render the home view)...

router.get("/",async function (req, res) {

    listOfArticles = await articleDao.retrieveAllArticleDateDesc();
    userAvatarIcons = await usersDao.retrieveAllUsers();

    const empty = await getPost(listOfArticles);
    res.locals.article = listOfArticles;
    res.locals.userAvatarIcons = userAvatarIcons;

    // Dynamic title and css import using handlebars
    res.render("home", { layout:"main", title: "Pokemon Collect", css: ['main.css'] , scripts: [{ script: '/js/header-resizer.js' }]});
    
});

router.get("/home", async function (req,res){

    const empty = await getPost(listOfArticles);
    res.locals.article = listOfArticles;

    userAvatarIcons = await usersDao.retrieveAllUsers();
    res.locals.userAvatarIcons = userAvatarIcons;

    // Dynamic title and css import using handlebars
    res.render("home", { layout:"main", title: "Pokemon Collect", css: ['main.css'] , scripts: [{ script: '/js/header-resizer.js' }]});
});

router.get("/newest",async function (req, res) {
    listOfArticles = await articleDao.retrieveAllArticleDateDesc();
    userAvatarIcons = await usersDao.retrieveAllUsers();
    res.redirect("/home");
});

router.get("/oldest",async function (req, res) {
    listOfArticles = await articleDao.retrieveAllArticleDateAsc();
    userAvatarIcons = await usersDao.retrieveAllUsers();
    res.redirect("/home");
});

router.get("/mostComments",async function (req, res) {
    listOfArticles = await articleDao.retrieveAllArticleCommentDesc();
    userAvatarIcons = await usersDao.retrieveAllUsers();
    res.redirect("/home");
});

router.get("/leastComments",async function (req, res) {
    listOfArticles = await articleDao.retrieveAllArticleCommentAsc();
    userAvatarIcons = await usersDao.retrieveAllUsers();
    res.redirect("/home");
});


router.get("/myPosts", verifyAuthenticated, async function (req,res){
    const listOfArticles = await articleDao.retrieveArticleByUser(res.locals.user.id);
    const empty = await getPost(listOfArticles);
    res.locals.article = listOfArticles;
    userAvatarIcons = await usersDao.retrieveAllUsers();
    res.locals.userAvatarIcons = userAvatarIcons;
    res.render("home-myposts", { layout:"myposts",title: "My Posts", css: ['main.css'], scripts: [{ script: '/js/header-resizer.js' }]});
});

async function getPost(listOfArticles){
    if(listOfArticles.length < 1){

        return false;
    }
    for(const article of listOfArticles) {
        let listOfComments = await commentDao.retrieveCommentsOfArticle(article.id);
        article.comment = listOfComments;
    }
    return true;
}

module.exports = router;










