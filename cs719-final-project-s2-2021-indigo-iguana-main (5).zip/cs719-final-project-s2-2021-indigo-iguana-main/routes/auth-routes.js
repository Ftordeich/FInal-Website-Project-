//This file provides routers for user authentication

//Password encryption module initialize. (need to run npm install --save bcrypt)
const bcrypt = require('bcrypt');
const saltRounds = 10;

const { v4: uuid } = require("uuid");
const express = require("express");
const router = express.Router();

// The DAO that handles CRUD operations for users.
const userDao = require("../modules/user-dao.js");

const { verifyAuthenticated } = require("../middleware/auth-middleware.js");


// Whenever we navigate to /login, if we're already logged in, redirect to "/".
// Otherwise, render the "login" view.
router.get("/login", function (req, res) {

    if (res.locals.user) {
        res.redirect("/");
    }

    else {
        res.render("account-login", { layout: "accounts", title: "Login", css: ['login-register-account.css'] });
    }

});

// Whenever we POST to /login, check the username and password submitted by the user.
// If they match a user in the database, give that user an authToken, save the authToken
// in a cookie, and redirect to "/". Otherwise, redirect to "/login", with a "login failed" message.
router.post("/login", async function (req, res) {

    // Get the username and password submitted in the form
    const username = req.body.username;
    const password = req.body.password;
    // Find a matching user in the database
    const user = await userDao.retrieveUserByUsername(username);

    // if there is a matching user...
    if (user) {

        //Use bcrypt to compare the password user entered and the encrypted password stored in the database
        const match = await bcrypt.compare(password, user.password);

        //if the combination of username and password is correct
        if (match) {
            // Auth success - give that user an authToken, save the token in a cookie, and redirect to the homepage.
            const authToken = uuid();
            user.authToken = authToken;
            await userDao.updateUser(user);
            res.cookie("authToken", authToken);
            res.locals.user = user;
            res.redirect("/");
        }
        //if username is valid but password is not correct
        else {
            // Auth fail
            res.locals.user = null;
            res.setToastMessage("Incorrect password!");
            res.redirect("./login");
        }
    }

    // Otherwise, if there's no matching username...
    else {
        // Auth fail
        res.locals.user = null;
        res.setToastMessage("User not found!");
        res.redirect("./login");
    }
});

// Whenever we navigate to /logout, delete the authToken cookie.
// redirect to "/login", supplying a "logged out successfully" message.
router.get("/logout", function (req, res) {
    res.clearCookie("authToken");
    res.locals.user = null;
    res.setToastMessage("Successfully logged out!");
    res.redirect("./login");
});

// Account creation
router.get("/newAccount", function (req, res) {
    res.render("account-signup", { layout: "accounts", title: "Sign up", css: ['signup.css'], scripts: [{ script: '/js/user-auth.js' }] });
})

router.post("/newAccount", async function (req, res) {
    //Encrypt the user's password then store into the user object
    const hashedPassword = await bcrypt.hash(req.body.password, saltRounds)

    const user = {
        username: req.body.username,
        password: hashedPassword,
        fname: req.body.fname,
        lname: req.body.lname,
        date_of_birth: req.body.date_of_birth,
        description: req.body.description,
        email: req.body.email,
        avatar: "ash"
    };

    try {
        await userDao.createUser(user);
        res.setToastMessage("Account created! Please select an Avatar");
        const authToken = uuid();
        user.authToken = authToken;
        await userDao.updateUser(user);
        res.cookie("authToken", authToken);
        res.locals.user = user;
        res.redirect("/");
    }
    catch (err) {
        res.redirect("/newAccount");
    }
});



// Display the View for user account edits
router.get("/accountManagement", verifyAuthenticated, async function (req, res) {
    res.render("account-management", { layout: "accounts", title: "Account management", css: ['signup.css'], scripts: [{ script: '/js/user-auth.js' }] });
});


router.post("/accountManagement",verifyAuthenticated,async function (req, res) {
    const hashedPassword = await bcrypt.hash(req.body.password, saltRounds)

    const user = {
        id: res.locals.user.id,
        username: req.body.username,
        password: hashedPassword,
        fname: req.body.fname,
        lname: req.body.lname,
        date_of_birth: req.body.date_of_birth,
        description: req.body.description,
        email: req.body.email
    };
    try {
        await userDao.updateUser(user);
    }
    catch (err) {
        res.redirect("/");
    }

    res.redirect("/");
});

router.post("/deleteAccount", verifyAuthenticated, async function (req, res) {

    const user = res.locals.user
    await userDao.deleteUser(user.id);

    res.setToastMessage("Account deleted!");

    res.redirect("/");
});

module.exports = router;