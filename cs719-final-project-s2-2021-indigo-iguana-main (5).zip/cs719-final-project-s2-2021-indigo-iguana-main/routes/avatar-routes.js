//This file provides routers for avatars (both pre-defined and user uploaded avatars)

const express = require("express");
const router = express.Router();
const upload = require("../middleware/multer-uploader.js");
const fs = require("fs");

// The DAO that handles CRUD operations for users.
const userDao = require("../modules/user-dao.js");

//Render the avatar view for the user to select their desired avatar
router.get("/avatar", async function (req, res) {
    res.render("account-avatar", {layout:"accounts", title: "Avatar", css: ['avatar.css'] });
});

/*Handle the user post request. If the user uploaded a personal avatar, store the image and assign 
  the user their avatar image. Else, obtain the users choice from the predfined avatar selection*/
router.post("/avatar", upload.single("imageFile"), async function(req, res){
    
    //Get the user object
    const currentUser = res.locals.user;

    //Get the uploaded user avatar image file
    const userImage = req.file;

    //If the user uploads a personal image/avatar, store the file and update the database
    if (userImage) { 
        const oldImgName = userImage.path;
        const newImgName = `./public/images/avatar/${userImage.originalname}`;
        fs.renameSync(oldImgName,newImgName);
        currentUser.avatar = `/images/avatar/${userImage.originalname}`;  
        await userDao.updateAvatar(currentUser);
    }
    else { 
        //Upload the selected user avatar to the server
        currentUser.avatar =  `/images/avatar/avatar-${req.body.avatar}.png`;
        await userDao.updateAvatar(currentUser);
    }
    res.redirect("/");
});

module.exports = router;



