/**This file provides routes to serve data from database to the users.*/

// Importing required modules
const express = require("express");
const userDAO = require("../modules/user-dao.js");
const articleDAO = require("../modules/article-dao.js");

// Setup an express Router
const router = express.Router();

/**This function simply get all the exist usernames from the database.
 */
router.get("/services/usernames",async function (req, res) {
    const allUserNames = await userDAO.retrieveAllUserName();
    res.json(allUserNames);
});

/**This function can be used when viewing a user's profile, it require a user id
*eg. /services/user?id=1 will get the user with id=1
 */
router.get("/services/user", async function (req,res){
    const user = await userDAO.retrieveUserById(req.query.id);
    res.json(user);
});


router.get("/services/tables", async function (req,res){
    const articles = await articleDAO.retrieveAllArticles();
    res.json(articles);
});


router.get("/services/articles", async function (req,res){
    const articles = await articleDAO.retrieveAllArticles();
    res.json(articles);
});


router.get("/services/createArticle", async function (req,res){
    
    const user = { 
        id: 1 
    }
    
    const article = { 
        title: "The first title placed ino the db",
        content: "Some content",
    }
    const newArticle = await articleDAO.createArticle(article,user);

});


router.get("/services/allArticles", async function (req,res){
    const articles = await articleDAO.retrieveAllArticles();
});


// Export the router so we can access it from other JS files using require()
module.exports = router;