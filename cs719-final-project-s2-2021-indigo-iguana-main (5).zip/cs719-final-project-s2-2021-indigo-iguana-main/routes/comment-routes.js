//This file provides routers for comments

const express = require("express");
const router = express.Router();
const { verifyAuthenticated } = require("../middleware/auth-middleware.js");

const commentDao = require("../modules/comment-dao.js");


/**If user have login, render the newArticle view which let user make new comments, else redirect to the login*/
router.get("/newComment",verifyAuthenticated,async function (req,res){
    res.render("comment-new", { layout:"editor",title: "New Comment", css: ['editor.css'] });
});


/** A route for create new comments.
 * First check if user already login. If so call the createComment with the current login user id and the current article id.*/
router.post("/newComment", verifyAuthenticated, async function (req, res) {
    
    const user = res.locals.user;

    const comment = {
        user_id : user.id,
        username: user.username,
        content: req.body.comment,
        commentLikes: 0,
        article_id: req.body.article_id
    }

    await commentDao.createComment(comment);
    res.redirect("/");
});

/** First check if user have login, then it get the user id and check if the user is the author of the comment.
 *  If both condition are ture, the editComment view is rendered  (user can edit the comment).
 */
router.get("/editComment", verifyAuthenticated, async function (req,res){
    
    const commentId = req.query.commentId;
    const comment  = await commentDao.retrieveCommnetById(commentId);
    const userId = comment.user_id;
    
    if(userId == res.locals.user.id){
        res.locals.content = comment.user_comment;
        res.locals.commment_id = commentId;
        res.render("comment-edit", { layout:"editor",title: "Edit Comment", css: ['editor.css'] });
    }
    
    else{
        res.setToastMessage("You do not have permission to edit the comment");
        res.redirect("/");
    }
});

/** A user can only edit the content of their comments.*/
router.post("/editComment", verifyAuthenticated, async function (req,res){
    const commentId = req.body.commentId;
    const comment = await commentDao.retrieveCommnetById(commentId);
    comment.user_comment = req.body.comment;

    await commentDao.updateComment(comment);
    res.redirect("/");
})

/** A user can delete his comments*/
router.get("/deleteComment", verifyAuthenticated, async function (req,res){
    
    const commentId = req.query.commentId;
    const comment  = await commentDao.retrieveCommnetById(commentId);
    const userId = comment.user_id;

    if(comment.user_id == res.locals.user.id){
        console.log("Here");
        await commentDao.deleteComment(commentId);
        res.setToastMessage("The comment is safely deleted");
        res.redirect("/");
    }
    else {
        res.setToastMessage("You do not have permission to delete the comment");
        res.redirect("/");
    }

});

/** Any user can like a comment*/
router.post("/likeComment", verifyAuthenticated, async function (req,res){
 
    const commentId = req.body.commentId;
    const comment  =await commentDao.retrieveCommnetById(commentId);
    const currentLikes = comment.comment_likes + 1;
    comment.comment_likes = currentLikes;

    await commentDao.likeComment(comment);
    
    res.redirect("/");
});


module.exports = router;