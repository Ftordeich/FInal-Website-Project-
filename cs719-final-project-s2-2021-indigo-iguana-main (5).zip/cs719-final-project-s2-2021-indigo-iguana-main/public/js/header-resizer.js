window.addEventListener("load", function () {

// scrolling resizes the main logo
    window.onscroll = function() {scrollFunction()};
    
    function scrollFunction() {
      if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
        document.getElementById("mainlogo").style.width = "230px";
      } else {
        document.getElementById("mainlogo").style.width = "488px";
      }
    }


    });

