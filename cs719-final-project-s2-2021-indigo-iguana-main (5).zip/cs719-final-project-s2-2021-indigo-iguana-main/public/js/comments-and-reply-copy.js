/**These functions are used to show and hide "+ comment" field and reply field in home.handlesbars.
 *
*/
window.addEventListener("load", function () {
    
  console.log("js1 imported");



  
  function commentfieldToggle() {
      const commentform = document.querySelector("#new-comment-form");
      const commentbutton = document.querySelector(".new-comment-button");
      const commentfield = document.querySelector("#newcommentfield");

      if (commentform.style.display === "block") {
        commentbutton.innerHTML="&nbsp;&nbsp;+&nbsp;New Comment";
        commentform.style.display = "none";
        commentfield.value="";
        
      } else {
        commentform.style.display = "block";
        commentbutton.innerHTML=`&nbsp;&nbsp;-&nbsp;Discard Comment`;
        
      }
    };

    function replyfieldToggle() {
      const replyform = document.querySelector("#new-reply-form");
      const replybutton = document.querySelector(".reply-button");
      const replyfield = document.querySelector("#newreplyfield");

      if (replyform.style.display === "block") {
        replybutton.innerHTML="Reply";
        replyform.style.display = "none";
        replyfield.value="";
        
      } else {
        replyform.style.display = "block";
        replybutton.innerHTML="Cancel Reply";
        
      }
    };



let commentbtn = document.querySelectorAll(".new-comment-button");
for (i = 0; i < commentbtn.length; i++) {
commentbtn[i].addEventListener("click", commentfieldToggle);
};


let replybtn = document.querySelectorAll(".reply-button");
for (i = 0; i < replybtn.length; i++) {
replybtn[i].addEventListener("click", replyfieldToggle);
};



});
