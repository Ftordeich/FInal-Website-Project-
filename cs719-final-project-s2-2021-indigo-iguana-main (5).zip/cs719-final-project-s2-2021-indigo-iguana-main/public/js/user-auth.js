
/**This function should be called when user finish typing the username.?
 *
*/
window.addEventListener("load", function () {
    const usernameInput = document.querySelector("#username");
    usernameInput.addEventListener('input', isUniqueUsername);
    const reEnterPassword = document.querySelector("#re-enter-password");
    reEnterPassword.addEventListener('input', isSamePassword);
});
    async function isUniqueUsername() {
        const usernameInput = document.querySelector("#username");
        const response = await fetch("./services/usernames");
        const alert = document.querySelector("#username-alert");
        const allUsernames = await response.json();
        for(const username of allUsernames){
            if (username.username == usernameInput.value) {
                alert.innerText = "The username is already be taken."
                usernameInput.classList.add("red");

                return false;
            }
        }


        usernameInput.classList.remove("red");
        alert.innerText = "";

        return true;
    }

    function isSamePassword() {
        const reEnterPassword = document.querySelector("#re-enter-password");
        const password = document.querySelector("#password");
        const alert = document.querySelector("#re-password-alert");
        if (password.value !== reEnterPassword.value) {
            alert.innerText = "The re-enter password must be the same as the password.";
            reEnterPassword.classList.add("red");

            return false;
        }
        reEnterPassword.classList.remove("red");
        alert.innerText="";

        return true;
    }


    async function check(form){
            if (isSamePassword()&&(await isUniqueUsername())){
                form.submit();
            }
    }





