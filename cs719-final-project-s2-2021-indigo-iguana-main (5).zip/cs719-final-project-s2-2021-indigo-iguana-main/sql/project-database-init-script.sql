drop table if exists message;
drop table if exists reply;
drop table if exists comment;
drop table if exists article;
drop table if exists user;

create table user ( 
	id integer not null primary key UNIQUE ,
	username varchar(64) NOT NULL, 
	password varchar(64) NOT NULL, 
	fname varchar(64),
	lname varchar(64),
	dob varchar(64), 
	description varchar(256),
	email varchar(64),
	date_created timestamp,
	avatar varchar(64),
	authToken varchar(128)
);


create table article ( 
	id INTEGER NOT NULL PRIMARY KEY, 
	title varchar(64), 
	author varchar(64), 
	date_created timestamp,
    created_by_id integer,
	tiny_mce text,
	user_avatar varchar(64),
    foreign key(created_by_id) references user(id) ON DELETE CASCADE
);


create table comment ( 
	id INTEGER NOT NULL PRIMARY KEY, 
	user_id integer,
	username varchar(64),
    user_comment text, 
	comment_likes integer, 
	date_created timestamp,
    article_id integer,
	foreign key(user_id) references user(id) ON DELETE CASCADE,
    foreign key(article_id) references article(id) ON DELETE CASCADE
);


create table reply ( 
	id INTEGER NOT NULL PRIMARY KEY, 
	user_id integer,
    user_response text, 
	reply_likes integer, 
	date_created timestamp,
    comment_id integer,
	foreign key(user_id) references user(id) ON DELETE CASCADE,
    foreign key(comment_id) references comment(id) ON DELETE CASCADE
);


create table message ( 
	id INTEGER NOT NULL PRIMARY KEY, 
	sender_id integer,
	receiver_id integer,
	body text, 
	date_created timestamp,
	foreign key(sender_id) references user(id) ON DELETE CASCADE
	foreign key(receiver_id) references user(id) ON DELETE CASCADE
);


insert into user(id,username,password,fname,lname,dob,description,email,date_created,avatar) values 
  	(1,'test user-one','user-one-password','user-one-firstname', 'user-one-lastname','user-one-1994','user-one- personal description','user1@gmail.com',date('now'),'ash'),
	(2,'test user-two','user-two-password','user-two-firstname', 'user-two-lastname','user-two-1995','user-two- personal description','user2@gmail.com',date('now'),'brock'),
	(3,'test user-three','user-three-password','user-three-firstname', 'user-three-lastname','user-three-1996','user-three- personal description','user3@gmail.com',date('now'),'misty'),
	(4,'test user-four','user-four-password','user-four-firstname', 'user-four-lastname','user-four-1994','user-four- personal description','user4@gmail.com',date('now'),'ash');
	
insert into article(title, date_created, created_by_id) values 
	('Article one title written by user-one', date('now'), 1),
	('Article two title written by user-two', date('now'), 2);

insert into comment( user_id, user_comment, comment_likes, date_created, article_id) values 
    (3,"test user-three comment on article one", 40, date('now'), 1),
    (4,"test user-four comment on article two", 15, date('now'), 2);
	
insert into reply(user_id, user_response, reply_likes, date_created, comment_id) values 
    (3,"test user-three replying on commnet one", 12, date('now'), 1),
    (4,"test user-four replying on comment two", 9, date('now'), 2);
