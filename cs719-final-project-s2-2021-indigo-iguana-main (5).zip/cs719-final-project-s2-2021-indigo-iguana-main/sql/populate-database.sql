BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "user" (
	"id"	integer NOT NULL UNIQUE,
	"username"	varchar(64) NOT NULL,
	"password"	varchar(64) NOT NULL,
	"fname"	varchar(64),
	"lname"	varchar(64),
	"dob"	varchar(64),
	"description"	varchar(256),
	"email"	varchar(64),
	"date_created"	timestamp,
	"avatar"	varchar(64),
	"authToken"	varchar(128),
	PRIMARY KEY("id")
);
CREATE TABLE IF NOT EXISTS "article" (
	"id"	INTEGER NOT NULL,
	"title"	varchar(64),
	"author"	varchar(64),
	"date_created"	timestamp,
	"created_by_id"	integer,
	"tiny_mce"	text,
	"user_avatar"	varchar(64),
	FOREIGN KEY("created_by_id") REFERENCES "user"("id") ON DELETE CASCADE,
	PRIMARY KEY("id")
);
CREATE TABLE IF NOT EXISTS "comment" (
	"id"	INTEGER NOT NULL,
	"user_id"	integer,
	"username"	varchar(64),
	"user_comment"	text,
	"comment_likes"	integer,
	"date_created"	timestamp,
	"article_id"	integer,
	FOREIGN KEY("user_id") REFERENCES "user"("id") ON DELETE CASCADE,
	FOREIGN KEY("article_id") REFERENCES "article"("id") ON DELETE CASCADE,
	PRIMARY KEY("id")
);
CREATE TABLE IF NOT EXISTS "message" (
	"id"	INTEGER NOT NULL,
	"sender_id"	integer,
	"receiver_id"	integer,
	"body"	text,
	"date_created"	timestamp,
	FOREIGN KEY("sender_id") REFERENCES "user"("id") ON DELETE CASCADE,
	FOREIGN KEY("receiver_id") REFERENCES "user"("id") ON DELETE CASCADE,
	PRIMARY KEY("id")
);
INSERT INTO "user" VALUES (1,'Ash','$2b$10$1B9hu7pXAEVQtHMIRvF5aOgqpkPWpJDV2vOI3pPk/R0A8IIQmjsuO','Ash','Ketchum',NULL,'Hi there','ash@pokemon.com',NULL,'/images/avatar/avatar-ash.png','7b80bc99-e6aa-4c53-8cff-7e5770c4ee10');
INSERT INTO "user" VALUES (2,'Brock','$2b$10$/QuYfW/otrDQQeGRLhFQvuTPLgwkr7.OFEhKNtt73fFjn/6DKwR.q','Brock','Rock','0011-11-11','I Rock!','brock@pokemon.com',NULL,'/images/avatar/avatar-brock.png','ec6a6f90-3f67-45b4-97c4-6c5206fadd93');
INSERT INTO "user" VALUES (3,'Misty','$2b$10$sZLA0l.7LC/oFe619ynoJuImIxEq19QkhTC/qMNMYVvMUzSegbEXq','Misty','Q','2021-11-05','Hello Im Misty','misty@pokemon.com',NULL,'/images/avatar/avatar-misty.png','e919f462-e0b0-4197-abf7-a336484201f6');
INSERT INTO "user" VALUES (4,'James','$2b$10$WDR5naW19URTjoF48NBlt.Hx2k/xKKX9wOGzxfgq3UMqFk3M3ax9.','James','Rocket',NULL,'team rocket!','james@pokemon.com',NULL,'/images/avatar/avatar-james.png','a24feb26-7d72-4771-8dbb-ff21258c2cac');
INSERT INTO "user" VALUES (5,'Jessie','$2b$10$tXbhtviP8W5Qf3QFE1ZfAOkGrrD4x8vsPKaJad0HjapIdv5fXBDX6','Jessie','Rocket','0022-02-22','Prepare for trouble','jessie@pokemon.com',NULL,'/images/avatar/avatar-jessie.png','bc0a085a-06b1-46d9-91cb-87a8039b6616');
INSERT INTO "user" VALUES (6,'Gary','$2b$10$Uf30NUJ/814TFMkHhG3E9.BnvSTY2aEjvG2sm6LmsRzOzafAMwDFS','Gary','Oak','2021-05-07','Im Prof Oaks grandson!','gary@pokemon.com',NULL,'/images/avatar/avatar-gary.png','68f49c74-5ba5-4aea-a9e6-d2af42fa5877');
INSERT INTO "article" VALUES (1,'Check out these Legendary Pokemons I found!','Ash','2021-11-07 08:18:01',1,'<p style="text-align: center;"><img src="https://cdn2.bulbagarden.net/upload/d/d1/2016_Mythical_Pok%C3%A9mon_Distributions_artwork.png" alt="" width="759" height="542" /></p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;"><strong style="font-family: sans-serif; font-size: 12.7px; text-align: start; background-color: #ffffff;">Legendary Pok&eacute;mon</strong><span style="font-family: sans-serif; font-size: 12.7px; text-align: start;">&nbsp;(</span><em style="font-family: sans-serif; font-size: 12.7px; text-align: start; background-color: #ffffff;">Legendary Pok&eacute;mon</em><span style="font-family: sans-serif; font-size: 12.7px; text-align: start;">) are a group of incredibly rare and often very powerful&nbsp;</span><a style="color: #0645ad; text-decoration-line: none; background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; font-family: sans-serif; font-size: 12.7px; text-align: start;" title="Pok&eacute;mon (species)" href="https://bulbapedia.bulbagarden.net/wiki/Pok%C3%A9mon_(species)">Pok&eacute;mon</a><span style="font-family: sans-serif; font-size: 12.7px; text-align: start;">, generally featured prominently in the legends and myths of the Pok&eacute;mon world.</span></p>','/images/avatar/avatar-ash.png');
INSERT INTO "article" VALUES (2,'One Question','Brock','2021-11-07 08:22:03',2,'<p><img style="display: block; margin-left: auto; margin-right: auto;" src="https://cdn2.bulbagarden.net/upload/0/0a/Forest_of_Okoya_Zarude.png" alt="" width="583" height="751" /></p>
<p>&nbsp;</p>
<p style="text-align: right;">any one know this pokemon''s name?</p>
<p style="text-align: right;">he looks pretty <span style="font-size: 24pt;"><span style="font-family: impact, sans-serif;">cool</span>~</span></p>','/images/avatar/avatar-brock.png');
INSERT INTO "article" VALUES (3,'Two Cool Pokemons!','Misty','2021-11-07 08:27:08',3,'<h2 style="text-align: center;">I got these<span style="text-decoration: underline;"> two</span> today!</h2>
<p>&nbsp;</p>
<p><img style="display: block; margin-left: auto; margin-right: auto;" src="https://cdn2.bulbagarden.net/upload/7/79/Hero_duo.png" alt="" width="540" height="446" /></p>
<p><span style="color: #b96ad9;"><em><strong>they look so cool don''t you think</strong></em></span></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>','/images/avatar/avatar-misty.png');
INSERT INTO "article" VALUES (4,'Look here I like my Pokemons!','James','2021-11-07 08:30:20',4,'<p><img src="https://cdn2.bulbagarden.net/upload/9/9f/Ultra_Sun_Ultra_Moon_Necrozma_Solgaleo_Lunala_artwork.png" alt="" width="898" height="635" /></p>
<p>&nbsp;</p>
<p>Intense!</p>','/images/avatar/avatar-james.png');
INSERT INTO "article" VALUES (5,'REAL this time?','James','2021-11-07 08:32:56',4,'<p><img style="display: block; margin-left: auto; margin-right: auto;" src="https://cdn2.bulbagarden.net/upload/9/9f/Ultra_Sun_Ultra_Moon_Necrozma_Solgaleo_Lunala_artwork.png" alt="" width="682" height="482" /></p>','/images/avatar/avatar-james.png');
INSERT INTO "article" VALUES (6,'Team Rocket Motto','Jessie','2021-11-07 08:34:56',5,'<p style="text-align: center;"><span style="font-family: terminal, monaco, monospace;">Prepare for trouble!</span></p>
<p style="text-align: center;"><span style="font-family: terminal, monaco, monospace;">And make it double!</span></p>
<p style="text-align: center;"><span style="font-family: terminal, monaco, monospace;">To protect the world from devastation!</span></p>
<p style="text-align: center;"><span style="font-family: terminal, monaco, monospace;">To unite all peoples within our nation!</span></p>
<p style="text-align: center;"><span style="font-family: terminal, monaco, monospace;">To denounce the evils of truth and love!</span></p>
<p style="text-align: center;"><span style="font-family: terminal, monaco, monospace;">To extend our reach to the stars above!</span></p>
<p style="text-align: center;"><span style="font-family: terminal, monaco, monospace;">Jessie!</span></p>
<p style="text-align: center;"><span style="font-family: terminal, monaco, monospace;">James!</span></p>
<p style="text-align: center;"><span style="font-family: terminal, monaco, monospace;">Team Rocket blasts off at the speed of light!</span></p>
<p style="text-align: center;"><span style="font-family: terminal, monaco, monospace;">Surrender now, or prepare to fight!</span></p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;"><span style="font-family: terminal, monaco, monospace;">Meowth!</span></p>
<p style="text-align: center;"><span style="font-family: terminal, monaco, monospace;">That''s right!</span></p>','/images/avatar/avatar-jessie.png');
INSERT INTO "article" VALUES (7,'My First Post! I am the Best','Gary','2021-11-07 08:43:29',6,'<p style="text-align: center;"><span style="font-family: ''comic sans ms'', sans-serif;">Check out my Pokemons!</span></p>
<p style="text-align: center;"><span style="font-family: ''comic sans ms'', sans-serif;">I''m the Best!</span></p>
<p><img style="display: block; margin-left: auto; margin-right: auto;" src="https://cdn2.bulbagarden.net/upload/a/a0/Fula_City_Zeraora.png" alt="" width="521" height="521" /></p>','/images/avatar/avatar-gary.png');
INSERT INTO "comment" VALUES (1,1,'Ash','Contact me if you want to see these, I will take you there',3,'2021-11-07',1);
INSERT INTO "comment" VALUES (2,2,'Brock','Hey Ash where did you see this?',1,'2021-11-07',1);
INSERT INTO "comment" VALUES (3,3,'Misty','Cool Ash!',0,'2021-11-07',1);
INSERT INTO "comment" VALUES (4,4,'James','Can I Steal these?',1,'2021-11-07',1);
INSERT INTO "comment" VALUES (5,4,'James','I hate fake PNGs',1,'2021-11-07',4);
INSERT INTO "comment" VALUES (6,4,'James','TWO WOW',2,'2021-11-07',3);
INSERT INTO "comment" VALUES (7,4,'James','Hey Brock what are you up today, want to join team rocket? we want you!',1,'2021-11-07',2);
INSERT INTO "comment" VALUES (8,4,'James','Can I have one?',0,'2021-11-07',3);
INSERT INTO "comment" VALUES (9,4,'James','No It''s still a fake PNG',0,'2021-11-07',5);
INSERT INTO "comment" VALUES (10,5,'Jessie','What are you doing here James!',0,'2021-11-07',5);
INSERT INTO "comment" VALUES (11,6,'Gary','You are a loser Ash!',0,'2021-11-07',1);
INSERT INTO "comment" VALUES (12,6,'Gary','Good stuff',0,'2021-11-07',6);
INSERT INTO "comment" VALUES (13,6,'Gary','you are stupid',0,'2021-11-07',5);
INSERT INTO "comment" VALUES (14,6,'Gary','not cool',0,'2021-11-07',3);
INSERT INTO "comment" VALUES (15,6,'Gary','Easy',0,'2021-11-07',2);
INSERT INTO "comment" VALUES (16,6,'Gary','Like my comments guys',1,'2021-11-07',7);
INSERT INTO "comment" VALUES (17,6,'Gary','where dont you like me!',1,'2021-11-07',7);
INSERT INTO "message" VALUES (1,2,1,'Hey Ash, you there?','2021-11-07 08:22:46');
INSERT INTO "message" VALUES (2,2,1,'Where did you see it?','2021-11-07 08:22:55');
INSERT INTO "message" VALUES (3,3,2,'Hi Brock how are you','2021-11-07 08:27:23');
INSERT INTO "message" VALUES (4,3,1,'Hi Ash','2021-11-07 08:27:31');
INSERT INTO "message" VALUES (5,4,2,'Ready to join team rocket Brock?','2021-11-07 08:31:58');
INSERT INTO "message" VALUES (6,4,1,'Hey Ash Can I steel your pikachu?','2021-11-07 08:32:17');
INSERT INTO "message" VALUES (7,5,4,'James!','2021-11-07 08:36:52');
INSERT INTO "message" VALUES (8,5,4,'What are you doing?','2021-11-07 08:36:58');
INSERT INTO "message" VALUES (9,5,3,'Hi Misty, Like my hair?','2021-11-07 08:37:13');
INSERT INTO "message" VALUES (10,5,3,'I like it','2021-11-07 08:37:20');
INSERT INTO "message" VALUES (11,6,1,'Hi Ash You want to Battle!','2021-11-07 08:41:02');
INSERT INTO "message" VALUES (12,6,2,'Hey Loser!','2021-11-07 08:41:13');
INSERT INTO "message" VALUES (13,6,3,'Misty!','2021-11-07 08:41:24');
INSERT INTO "message" VALUES (14,6,4,'Hi James','2021-11-07 08:41:33');
INSERT INTO "message" VALUES (15,6,5,'Hi Jessie','2021-11-07 08:41:42');
COMMIT;
