//This file is the middleware for user authentication. It let the server check the state of authentication before loading the page.

const userDao = require("../modules/user-dao.js");

async function addUserToLocals(req, res, next) {
    const user = await userDao.retrieveUserWithAuthToken(req.cookies.authToken);
    res.locals.user = user;
    next();
}

function verifyAuthenticated(req, res, next) {
    //If user have login...
    if (res.locals.user) {
        //console.log("user have login");
        next();
    }
    //If user have not login (redirect to the login page)...
    else {
        //console.log("user have not login");
        res.redirect("./login");
    }
}

module.exports = {
    addUserToLocals,
    verifyAuthenticated
}