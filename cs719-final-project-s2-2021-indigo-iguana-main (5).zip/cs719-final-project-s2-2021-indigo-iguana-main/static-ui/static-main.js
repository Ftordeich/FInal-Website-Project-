window.addEventListener("load", function () {


    function addpost(post) {
        

     const postsLayout = document.querySelector("#container");

     const postMain = document.createElement("div");
     postMain.classList.add("post");
     const postTitle = document.createElement("h2");
     postTitle.classList.add("post-title");
     const postDatetime = document.createElement("p");
     postDatetime.classList.add("post-datetime");
     const postText = document.createElement("p");
     postText.classList.add("post-text");

      

    postMain.innerHTML = ``;
    postTitle.innerHTML = `${posts [post].title}`;
    postDatetime.innerHTML = `${posts [post].datetime}`;
    postText.innerHTML = `${posts [post].text}`;
   
    postsLayout.appendChild(postMain);  
    postMain.appendChild(postTitle);
    postMain.appendChild(postDatetime);
    postMain.appendChild(postText);
    }

 
    
    posts.forEach(function addFunction (novalue,index){

        // adds a setTimeout delay before each addpost function is looped
        setTimeout(postAdder,(index+1)*285);

        function postAdder() {
            addpost(`${index}`);
        }

    });

});