window.addEventListener("load", function() {

    //Redirecting to 'home' after signup// 

    const loginBtnSelector = document.querySelector("#loginbutton");

    loginBtnSelector.addEventListener("click",function(){
            console.log("Login Button");
            });
    


});