const posts = [

    {
        title: "Rare Candy (MINT CONDITION)",
        datetime: "01-08-2021  07:30:41",
        text: "MUST SELL (₽300) <br> I obtained this Rare candy in the Viridian Forest, in Mint Condition. Never used. You can use this on any type of Pokemon. I will also consider trading it for a pikachu. Remember: Pick up only (I am a very busy man...)",
        
    },
    {
        title: "Rare Candy (MINT CONDITION)",
        datetime: "01-08-2021  07:30:41",
        text: "MUST SELL (₽300) <br> I obtained this Rare candy in the Viridian Forest, in Mint Condition. Never used. You can use this on any type of Pokemon. I will also consider trading it for a pikachu. Remember: Pick up only (I am a very busy man...)",
        
        
    },
    {
        title: "Rare Candy (MINT CONDITION)",
        datetime: "01-08-2021  07:30:41",
        text: "MUST SELL (₽300) <br> I obtained this Rare candy in the Viridian Forest, in Mint Condition. Never used. You can use this on any type of Pokemon. I will also consider trading it for a pikachu. Remember: Pick up only (I am a very busy man...)",
        
        
    },
    {
        title: "Rare Candy (MINT CONDITION)",
        datetime: "01-08-2021  07:30:41",
        text: "MUST SELL (₽300) <br> I obtained this Rare candy in the Viridian Forest, in Mint Condition. Never used. You can use this on any type of Pokemon. I will also consider trading it for a pikachu. Remember: Pick up only (I am a very busy man...)",
        
    },
    {
        title: "Rare Candy (MINT CONDITION)",
        datetime: "01-08-2021  07:30:41",
        text: "MUST SELL (₽300) <br> I obtained this Rare candy in the Viridian Forest, in Mint Condition. Never used. You can use this on any type of Pokemon. I will also consider trading it for a pikachu. Remember: Pick up only (I am a very busy man...)",
        
        
    },
    {
        title: "Rare Candy (MINT CONDITION)",
        datetime: "01-08-2021  07:30:41",
        text: "MUST SELL (₽300) <br> I obtained this Rare candy in the Viridian Forest, in Mint Condition. Never used. You can use this on any type of Pokemon. I will also consider trading it for a pikachu. Remember: Pick up only (I am a very busy man...)",
        
        
    }

];

articles 