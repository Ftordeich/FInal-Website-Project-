window.addEventListener("load", function () {

    

    // checking the empty div above the close "X" button for close button function

    const closeBtnSelector = document.querySelector("#emptydiv-closeBtn");

    closeBtnSelector.addEventListener("click",function(){
            console.log("Close Button");
            });



    // checking the "Login" img button
    const loginBtnSelector = document.querySelector("#loginbutton");

    loginBtnSelector.addEventListener("click",function(){
            console.log("Login Button");
            });


    // checking the "New User" button  
    const newuserBtnSelector = document.querySelector("#textbutton-new");

    newuserBtnSelector.addEventListener("click",function(){
            console.log("New User");
            });
       
         





            

    


});